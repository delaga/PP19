// postaviti poveznice na svaki od kreiranih datoteka
<hr />
<ol>
    <li>
        <a href="korisneFunkcije.php">Korisne funkcije</a>
    </li>
    <li>
        <a href="varijable.php">Varijable</a>
    </li>
    <li>
        <a href="operatori.php">Operatori</a>
    </li>
    <li>
        <a href="nizovi.php">Nizovi</a>
    </li>
    <li>
        <a href="ugradeniNizovi.php">Ugrađeni nizovi</a>
    </li>
</ol>
Ostalo pogledati u projekt

<h1>
Na svoj server postaviti jednu stranicu koja pokazuje
jedan princip odrađen na nastavi
</h1>
