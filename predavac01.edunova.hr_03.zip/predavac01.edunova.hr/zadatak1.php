<h1>
<?php

// Program prima ime grada i ispisuje ga kao glavni naslov (H1)

echo $_GET["imeGrada"];
?>
</h1>

