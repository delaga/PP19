<?php

var_dump($argv);