<?php

//temeljni postulat programiranja
// VARIJABLA je prostor u memoriji

//deklaracija barijable
$x=3;
var_dump($x);

echo "<hr />";

$x="Osijek";

var_dump($x);

echo "<hr />";

$x=false;

var_dump($x);

echo "<hr />";

$x=4.3;

var_dump($x);

echo "<hr />";

$x=[];

var_dump($x);

//OOP
echo "<hr />";

$x=new stdClass();

var_dump($x);



