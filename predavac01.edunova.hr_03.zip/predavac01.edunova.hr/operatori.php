<?php

// 23 i 12 dođu kao parametri iz GET/POST-a

$prviBroj = 22;

$drugiBroj = 12;

$zbroj = $prviBroj + $drugiBroj;

echo $zbroj;

echo "<hr />";
echo $prviBroj . $drugiBroj;

//operatori - * /

// %
echo "<hr />";

echo 5 % 2;

echo "<hr />";

echo 5 ** 2;

// https://www.php.net/manual/en/language.operators.php