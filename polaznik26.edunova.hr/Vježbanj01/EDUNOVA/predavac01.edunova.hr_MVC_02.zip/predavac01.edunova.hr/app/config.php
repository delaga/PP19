<?php

return [
    "url"=>"http://predavac01.edunova.hr:8080/",
    "nazivApp" => "Edunova APP"
];