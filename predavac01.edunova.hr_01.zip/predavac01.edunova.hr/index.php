<?php

// komentar jedna linija

/*

komentar više linija

*/

echo "hello"," \n";
print "pero\n"; 

echo 'tekst\n'; //\n ne prolazi
echo "\tovo je 'pod dvostrukima' \n";
echo ' ovo e pod "jednostrukima" \n'; //\n ne prolazi

echo ' kako ispisati jednustriku pod jednostrukim \'  \n'; //\n ne prolazi



