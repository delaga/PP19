<?php
echo "<pre>";

print_r($_SERVER);


var_dump($_SERVER);
echo "</pre>";