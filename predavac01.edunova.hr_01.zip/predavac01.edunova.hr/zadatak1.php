<?php


// Ispisati brojeve 1,2,3 u novim redovima u HTML pregledniku

echo "1<br />2<hr />3";