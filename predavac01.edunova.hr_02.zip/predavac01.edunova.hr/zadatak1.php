<?php

// u odnosu na primljenu vrijednost GET parametra boja
// cijelu stranicu obojajte u primljenu boju

echo "<body style=\"background-color: " , $_GET["boja"], "\"></body>";