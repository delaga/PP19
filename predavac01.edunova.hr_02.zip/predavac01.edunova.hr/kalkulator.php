<?php

print_r($_GET);

echo $_GET["pb"] + $_GET["db"];