<?php 

// do while petlja

$i=false;

do{

    echo "Osijek";

}while($i);

// continue i break rade jednako
//ugnježđivanje radi jednako