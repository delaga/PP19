<?php

// ispisati sve parne brojeve od 1 do 59 odvojeno zarezom

for($i=1;$i<59+1;$i++){
    if($i%2===0){
        echo $i,", ";
    }
}