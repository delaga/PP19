<?php

$i=2;$j=1;
$i=$j++; //$i=1 $j=2
$j+=$i; // $i=1 $j=3

echo ++$i + $j--; //5


//DOMAĆA ZADAĆA: zadati si nekoliko primjera i izračunati ručno