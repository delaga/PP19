<?php

// višestruko grananje

$i=32;

switch($i){
    case 1:
    echo "Nedovoljan";
    break;
    case 2:
    echo "Dovoljan";
    break;
    case 3:
    echo "Dobar";
    break;
    default:
    echo "ostalo";
}


$grad="Osijek";

switch ($grad) {
    case 'Osijek':
        echo "OK";
        break;
    
    default:
        echo "NE";
        break;
}

